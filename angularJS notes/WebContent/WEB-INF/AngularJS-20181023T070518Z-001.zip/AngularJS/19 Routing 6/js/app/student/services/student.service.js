angular.module('StudentModule').service('StudentService', ['$http', function($http){
	
	this.getStudents = function(){
		return $http.get("http://localhost:3000/students");
	}

	this.saveStudent = function(i,j){
		var student = new Object();
		student.id = i;
		student.name = j;
		return $http.post("http://localhost:3000/students", student);
	}

	this.updateStudent = function(obj){		
		return $http.put("http://localhost:3000/students/"+obj.id,obj);
	}

	this.loadStudent = function(i){
		return $http.get("http://localhost:3000/students/"+i);
	}

}])
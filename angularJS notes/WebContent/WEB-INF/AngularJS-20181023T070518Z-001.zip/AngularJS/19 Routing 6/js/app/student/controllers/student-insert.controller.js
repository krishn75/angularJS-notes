angular.module('StudentModule').controller('StudentInsertController', ['$scope','StudentService' ,function($scope,StudentService){

	$scope.id = "";
	$scope.name = "";

	$scope.save = function(){
		StudentService.saveStudent($scope.id,$scope.name).then(function(response){
			alert("inserted");
		})
	}
	
}])
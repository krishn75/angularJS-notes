angular.module('StudentModule').controller('StudentUpdateController', ['$scope','StudentService', '$routeParams',function($scope,StudentService,$routeParams){

	$scope.student={};

	$scope.id = $routeParams.studentid;

	if($scope.id){

		StudentService.loadStudent($scope.id ).then(function(response){
				$scope.student = response.data;
			})

	}

	$scope.update = function(){
		StudentService.updateStudent($scope.student).then(function(response){
			alert("updated");
		})
	}

	$scope.load = function() {
		StudentService.loadStudent($scope.student.id).then(function(response){
			$scope.student = response.data;
		})
	}
	
}])
var p1=angular.module('projectApp', []);


p1.controller('c2', ['$scope','s1', function($scope,s1){
	
	$scope.id = "";
	$scope.name = "";

	$scope.update = function(){
		s1.updateStudent($scope.id,$scope.name).then(
			function(response){
				alert("updated");
			}
		);
	}

}])

p1.service('s1', ['$http', function($http){

	this.updateStudent = function(i,j){
		var student = new Object();
		student.id = i;
		student.name = j;
		return $http.put("http://localhost:3000/students/"+i, student);
	}
	
}])
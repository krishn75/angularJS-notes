// module

var p1 = angular.module('projectApp', []);

p1.controller('c1', ['$scope','s1', function($scope,s1){

	$scope.id = "";
	$scope.name = "";

	$scope.save = function(){
		s1.saveStudent($scope.id,$scope.name).then(function(response){
			alert("inserted");
		});
	}
	
}])

p1.service('s1', ['$http', function($http){

	this.saveStudent = function(a,b){
		var studentData = {};
		studentData.id = a;
		studentData.name = b;
		return $http.post("http://localhost:3000/students", studentData);
	}
	
}])
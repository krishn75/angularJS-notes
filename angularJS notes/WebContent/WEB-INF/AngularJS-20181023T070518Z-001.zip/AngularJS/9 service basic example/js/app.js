angular.module("projectapp",[]);


angular.module("projectapp").controller('c1', ['$scope','s1', 
		function($scope,s1){

			console.log("i am in c1");
	
}])

angular.module("projectapp").controller('c2', ['$scope','s1', 
		function($scope,s1){

			console.log("i am in c2");
	
}])

angular.module("projectapp").controller('c3', ['$scope','s1','s2',
		function($scope,s1,s2){

			console.log("i am in c3");
	
}])

angular.module("projectapp").service('s1', function(){

	console.log("i am in service1");
	
})

angular.module("projectapp").service('s2', function(s3){

	console.log("i am in service2");
	
})

angular.module("projectapp").service('s3', function(){

	console.log("i am in service3");
	
})

angular.module('StudentModule').controller('StudentUpdateController', ['$scope','StudentService', function($scope,StudentService){

	$scope.id = "";

	$scope.name = "";

	$scope.update = function(){
		StudentService.updateStudent($scope.id,$scope.name).then(function(response){
			alert("updated");
		})
	}

	$scope.load = function() {
		StudentService.loadStudent($scope.id).then(function(response){
			$scope.id = response.data.id;
			$scope.name = response.data.name;
		})
	}
	
}])
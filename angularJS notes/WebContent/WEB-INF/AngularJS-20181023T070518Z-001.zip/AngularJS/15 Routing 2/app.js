var p1= angular.module('projectApp', ["ngRoute"]);

p1.config(['$routeProvider',function($routeProvider) {


	$routeProvider.when("/home", {
		templateUrl : "home.html"
	})

	$routeProvider.when("/contact", {
		templateUrl : "contact.html"
	})


	$routeProvider.when("/aboutUs", {
		templateUrl : "aboutUs.html"
	})

	$routeProvider.when("/list", {
		templateUrl : "student-list.html",
		controller:"c1"
	})


	$routeProvider.otherwise({
		templateUrl : "home.html"
	})

	
}])

p1.controller('c1', ['$scope','s1', function($scope,s1){

	$scope.students = [];

	s1.getStudents().then(function(response){
		$scope.students = response.data;
	})
	
}]);

p1.service('s1', ['$http', function($http){

	this.getStudents = function(){
		return $http.get("http://localhost:3000/students");
	}
	
}])
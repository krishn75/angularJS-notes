angular.module('StudentModule', ["ngRoute"]);

angular.module('StudentModule').config(['$routeProvider',function($routeProvider) {

	$routeProvider.when("/student/list",{
		templateUrl : "views/student/student-list.html",
		controller: "StudentListController"
	})

	$routeProvider.when("/student/insert",{
		templateUrl : "views/student/student-insert.html",
		controller: "StudentInsertController"
	})

	$routeProvider.when("/student/update", {
		templateUrl:"views/student/student-update.html",
		controller:"StudentUpdateController"
	})
	
}])
var p1= angular.module('projectApp', ["ngRoute","StudentModule"]);

p1.config(['$routeProvider',function($routeProvider) {


	$routeProvider.when("/home", {
		templateUrl : "views/common/home.html"
	})

	$routeProvider.when("/contact", {
		templateUrl : "views/common/contact.html"
	})


	$routeProvider.when("/aboutUs", {
		templateUrl : "views/common/aboutUs.html"
	})


	$routeProvider.otherwise({
		templateUrl : "views/common/home.html"
	})

	
}])
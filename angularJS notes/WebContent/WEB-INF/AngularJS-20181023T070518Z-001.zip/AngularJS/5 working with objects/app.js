var p1 = angular.module('projectApp', []);

p1.controller('c1', ['$scope', function($scope){
	var s1 = {"id":1,"name":"s1"};
	var s2 = {"id":2,"name":"s2"};
	var s3 = {"id":3,"name":"s3"};
	$scope.students = [s1,s2,s3];

}]);
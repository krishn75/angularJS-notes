var p1 = angular.module("projectapp",[]);
p1.controller('c1', ['$scope','s1', function($scope,s1){

	$scope.student =  new Object();

	$scope.save = function(){
		s1.insert($scope.student).then(function(serverdata){
			alert("inserted successfully");
		});
	}
	
}])

p1.service('s1', ['$http', function($http){
	this.insert = function(obj){
		return $http.post("http://localhost:3000/students",obj);
	}
}])
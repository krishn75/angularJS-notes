angular.module("projectApp",["toaster","ngAnimate"]);

angular.module('projectApp').controller('C1', ['$scope','toaster', function($scope,toaster){

	$scope.m1 = function(){
		toaster.pop({type: 'error', body: 'failed'});
	}
	
}])
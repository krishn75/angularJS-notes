angular.module('projectApp', []);

angular.module('projectApp').controller('c1', ['$scope','s1', function($scope,s1){
	
	$scope.students = [];


	$scope.m1 = function(){

		s1.getStudents().then(function(serverdata){



		$scope.students = serverdata.data;


	},function(error){

		alert("failure");

	});

	}


}])


angular.module('projectApp').service('s1', ['$http', function($http){

	this.getStudents = function(){
		return $http.get("http://localhost:3000/students");
	}
	
}])
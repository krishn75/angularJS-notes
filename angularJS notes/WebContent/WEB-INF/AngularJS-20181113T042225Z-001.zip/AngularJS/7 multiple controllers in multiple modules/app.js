var p1 = angular.module('projectApp', ["m1","m2"]);

var m1 = angular.module("m1",[]);



m1.controller('c1', ['$scope', function($scope){
	$scope.message = "i am in m1 module and c1";
}])

var m2 = angular.module("m2",[]);
m2.controller('c2', ['$scope', function($scope){
	$scope.message = "i am in m2 module and c2";
}])
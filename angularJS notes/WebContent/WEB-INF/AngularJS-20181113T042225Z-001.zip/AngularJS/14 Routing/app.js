var p1=angular.module('projectApp', ["ngRoute"]);

p1.config(['$routeProvider',function($routeProvider) {

	$routeProvider.when("/home", {
		templateUrl:"home.html"
	})

	$routeProvider.when("/contact", {
		templateUrl:"contact.html"
	})
	
	$routeProvider.when("/aboutUs", {
		templateUrl:"aboutUs.html"
	})

	$routeProvider.otherwise({
		templateUrl:"home.html"
	})
}])
var app = angular.module("MyApp", []);
app.component("helloWorld",{
      template: 'Hello World!'
  });

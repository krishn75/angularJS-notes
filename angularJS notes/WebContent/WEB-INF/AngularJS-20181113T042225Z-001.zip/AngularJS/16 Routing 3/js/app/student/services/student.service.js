angular.module('StudentModule').service('StudentService', ['$http', function($http){
	
	this.getStudents = function(){
		return $http.get("http://localhost:3000/students");
	}

}])
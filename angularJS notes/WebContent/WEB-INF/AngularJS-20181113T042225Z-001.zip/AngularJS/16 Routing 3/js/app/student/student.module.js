angular.module('StudentModule', ["ngRoute"]);

angular.module('StudentModule').config(['$routeProvider',function($routeProvider) {

	$routeProvider.when("/student/list",{
		templateUrl : "views/student/student-list.html",
		controller: "StudentListController"
	})
	
}])
var p1=angular.module('projectApp', []);

p1.controller('c1', ['$scope', function($scope){
	
	$scope.message = "my first ex";

}])
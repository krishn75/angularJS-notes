angular.module("StudentModule").controller('StudentListController', ['$scope','StudentService', function($scope,StudentService){
	

	$scope.students  = [];

	$scope.getStudents = function(){
		StudentService.getStudents().then(function(response){
			$scope.students = response.data;
		});
	}

}])
var p1 = angular.module("projectapp",[]);


p1.controller('c1',function($scope){

	$scope.message = "i am in controller1";

});

p1.controller('c2', ['$scope', function($scope){

	$scope.message = "i am in controller2";
	
}])
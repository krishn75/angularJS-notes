var p1=angular.module('projectApp', []);

p1.controller('c1', ['$scope', function($scope){
	
	$scope.names = ["s1","s2","s3"];

	$scope.m1 = function(){
		$scope.names = ["s4","s5","s6"];
	}

}])
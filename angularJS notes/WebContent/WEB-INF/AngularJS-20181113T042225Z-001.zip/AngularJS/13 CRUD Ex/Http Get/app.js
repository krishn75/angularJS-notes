// module

var p1 = angular.module('projectApp', []);

p1.controller('c1', ['$scope','s1', function($scope,s1){

$scope.students = [];

s1.getStudents().then(function(response){
	$scope.students = response.data;
})
	
}])

p1.service('s1', ['$http', function($http){

	
	this.getStudents = function(){
		return $http.get("http://localhost:3000/students");
	}

}])